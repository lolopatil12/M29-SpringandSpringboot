package org.tnsif.placemanagement.repostier;

import org.springframework.data.jpa.repository.JpaRepository;
import org.tnsif.placemanagement.entities.admin;

public interface adminrepository extends JpaRepository<admin,Integer>{
	

}
