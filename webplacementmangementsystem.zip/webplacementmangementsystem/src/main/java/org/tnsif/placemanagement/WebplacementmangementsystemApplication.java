package org.tnsif.placemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebplacementmangementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebplacementmangementsystemApplication.class, args);
		
	}

}
