package org.tnsif.autowiremodes;

public class SpellChecker {
	//DEFAULT CONSTRUCTOR
		public SpellChecker()
		{
			System.out.println("SpellChecker constructor");
		}

		public void checkSpeelling()
		{
			System.out.println("Checking the spelling and correcting it");
		}

}
