package org.tnsif.placemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebplacementmangementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
