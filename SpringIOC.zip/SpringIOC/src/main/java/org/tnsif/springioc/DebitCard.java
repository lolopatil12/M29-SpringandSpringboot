package org.tnsif.springioc;
public interface DebitCard {
	//by default abstract
	
	void deposit();
	void withdraw();

}
